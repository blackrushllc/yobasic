# Basil Mini-DAW (Scaffold)
A minimal, keyboard-driven **terminal DAW** in **Basil** that showcases our Feature Objects:
- `obj-daw` (helpers: record/play/monitor/midi-capture/synth)
- `obj-audio`, `obj-midi` (low-level building blocks, optional in this scaffold)
- `obj-term` (Crossterm-backed terminal control: CLS/LOCATE/COLOR/etc.)

This scaffold focuses on a usable shell with a status header, screens you can flip between,
and a couple of *working actions* you can try immediately (record a quick memo, play it back).
From here, expand into a full timeline, mixer, and piano roll as discussed in the blueprint.

## Run (examples)
```bash
cargo run -p basilc --features obj-daw,obj-term,obj-audio -- run src/main.basil
```

### Hotkeys (scaffold)
- **F1** Help   • **F2** Arrangement • **F3** Mixer • **F4** Devices
- **Space** Play/Stop (placeholder)  • **R** Record (voice memo demo: 3s to `memo.wav` then playback)
- **Q** Quit

You should see a header/status bar, body area that changes per screen, and a footer with hints.
The **Record** demo uses `AUDIO_RECORD%` and `AUDIO_PLAY%` to prove the plumbing.

## Layout
```
basil-mini-daw/
├─ src/
│  ├─ main.basil         # entrypoint: UI loop + simple actions
│  ├─ ui.basil           # drawing helpers for screens
│  ├─ engine.basil       # transport placeholders (extend here)
│  └─ storage.basil      # project load/save stubs
├─ projects/
│  ├─ PianoJam/
│  │  └─ project.json    # simple demo project meta
│  └─ VoiceNote/
│     └─ project.json
└─ docs/
   └─ roadmap.md         # what's next
```


**New:** Real transport + metronome (Space toggles play, M toggles click, +/- adjust BPM).
