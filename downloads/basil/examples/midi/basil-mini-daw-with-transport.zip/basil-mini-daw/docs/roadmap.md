# Mini-DAW Roadmap (from scaffold to MVP)

## Phase 1: Make it musical
- Transport clock (samples↔BBT), global tempo, metronome click.
- Per-track synth instances (MIDI tracks) and WAV readers (audio tracks).
- Track arming + live-thru for MIDI and audio.

## Phase 2: Timeline & clips
- Project model in memory; load/save JSON.
- Clip scheduling in audio callback; loop region.
- Piano Roll screen: add/delete notes, quantize.

## Phase 3: Mixer & export
- Per-track gain/pan; master meter.
- Offline render to WAV.

## Phase 4: Ergonomics
- Undo/redo, autosave.
- Ratatui front-end swap (optional) reusing the same engine.
